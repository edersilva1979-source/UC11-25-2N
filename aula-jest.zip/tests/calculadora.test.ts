import {somar, subtrair, multiplicar, dividir} from "../src/calculadora";

test("deve somar 2+3 e retornar 5", () => {
    expect(somar(-2,-3)).toBe(-5);
});

test("deve subtrair -10 - -5 e retornar -5", () => {
    expect(subtrair(-10, -5)).toBe(-5);
});

test("deve mutiplicar 2*3 e retornar 6", () => {
    expect(multiplicar(2, 3)).toBe(6);
});

test("deve dividir 10/2 e retornar 5", () => {
    expect(dividir(10, )).toBe(5);
});